"""CLI for generating avocado codes from a Marshmallow schema."""
#
# ---------------------------------------------------------------------------------------------------------------------
#
from __future__ import annotations

import argparse
import importlib
import json
import sys
from typing import Dict, Optional, Sequence

from marshmallow import Schema

from avocado.avocado import Avocado, create
from avocado.exceptions import AvocadoException

#
# ---------------------------------------------------------------------------------------------------------------------
#

def _load_schema(target: str) -> Schema:
    """Load and instantiate a Marshmallow schema from a ``module:SchemaClass`` reference.

    Args:
        target: A reference of the form ``package.module:SchemaClass``.

    Returns:
        Schema: An instantiated schema.

    Raises:
        SystemExit: If the reference is malformed or the target is not a
            Marshmallow schema.
    """
    module_name, separator, attribute = target.partition(":")
    if not separator or not attribute:
        raise SystemExit(
            "Provide the schema as 'module:SchemaClass', e.g. app.schemas:UserSchema"
        )

    try:
        module = importlib.import_module(module_name)
    except ImportError as error:
        raise SystemExit(f"Module {module_name!r} could not be imported: {error}")

    # getattr is statically typed as Any -> narrow it via isinstance/issubclass
    # so mypy can verify the Schema return type.
    candidate: object = getattr(module, attribute, None)
    if not (isinstance(candidate, type) and issubclass(candidate, Schema)):
        raise SystemExit(f"{target!r} does not refer to a Marshmallow schema")

    return candidate()
#
# ---------------------------------------------------------------------------------------------------------------------
#


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser for the CLI.

    Returns:
        argparse.ArgumentParser: The configured argument parser.
    """
    parser = argparse.ArgumentParser(
        prog="avocado-codes",
        description="Generate avocado codes from a Marshmallow schema.",
    )
    parser.add_argument(
        "schema",
        metavar="MODULE:SCHEMA",
        help="Marshmallow schema, e.g. app.schemas:UserSchema",
    )
    parser.add_argument(
        "-o",
        "--output",
        metavar="FILE",
        default=None,
        help="Target file (default: write to stdout)",
    )
    return parser

#
# ---------------------------------------------------------------------------------------------------------------------
#

def main(argv: Optional[Sequence[str]] = None) -> int:
    """Generate codes from a schema and print or save them.

    Args:
        argv: An optional argument list (defaults to ``sys.argv``); eases testing.

    Returns:
        int: The exit code (0 on success, 1 on a code-generation error).
    """
    args = build_parser().parse_args(argv)
    schema_target: str = args.schema
    output_path: Optional[str] = args.output

    schema = _load_schema(schema_target)

    try:
        codes: Dict[str, str] = Avocado.generate_codes(schema)
        if output_path is not None:
            create().from_dict(codes).to_file(output_path)
        else:
            print(json.dumps(codes, ensure_ascii=False, indent=2))
    except AvocadoException as error:
        print(f"Failed to generate codes: {error}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
#
# ---------------------------------------------------------------------------------------------------------------------
#
